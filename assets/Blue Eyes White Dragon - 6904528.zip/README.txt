Blue Eyes White Dragon by Wynn-3D on Thingiverse: https://www.thingiverse.com/thing:6904528

Summary:
I summon my blue eyes!